package tme2;

@SuppressWarnings("serial")
public class NotClosedOperationException extends Exception {


	public  NotClosedOperationException(String mess){
		super(mess);
	}

}
