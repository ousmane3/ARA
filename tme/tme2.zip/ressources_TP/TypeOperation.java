package tme2;

public enum TypeOperation {
	READ, WRITE, NOTHING
}
